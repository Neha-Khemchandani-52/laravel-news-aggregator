SET NAMES utf8mb4;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(4,	'Demo Testing User',	'demotestesting@example.com',	NULL,	'$2y$12$gUbcBY29a1svjqw60iDjVOveqhrpHdoe3Ju.DUnHPxhyOad/KixJ6',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-09-27 20:26:11',	'2025-09-27 20:26:11');
-- 2025-09-28 12:28:40 UTC
