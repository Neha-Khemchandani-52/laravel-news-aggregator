SET NAMES utf8mb4;

INSERT INTO `article_category` (`article_id`, `category_id`) VALUES
(1,	8),
(2,	8),
(3,	8),
(4,	8),
(5,	8),
(6,	8),
(7,	8),
(8,	8),
(9,	8),
(10,	8);
-- 2025-09-28 12:23:58 UTC
