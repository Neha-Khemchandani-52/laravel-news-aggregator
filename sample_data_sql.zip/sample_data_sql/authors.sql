SET NAMES utf8mb4;

INSERT INTO `authors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1,	'Anonymous',	'2025-09-27 17:08:36',	'2025-09-27 17:08:36');
-- 2025-09-28 12:24:38 UTC
