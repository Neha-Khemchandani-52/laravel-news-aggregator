SET NAMES utf8mb4;

INSERT INTO `sources` (`id`, `name`, `slug`, `source-provider`, `meta`, `created_at`, `updated_at`) VALUES
(1,	'NewsAPI',	'newsapi',	'newsapi',	'\"{\\\"url\\\":\\\"https:\\\\/\\\\/newsapi.org\\\\/v2\\\\/everything\\\"}\"',	'2025-09-27 14:59:33',	'2025-09-27 14:59:33'),
(2,	'The Guardian',	'guardian',	'guardian',	'\"{\\\"url\\\":\\\"https:\\\\/\\\\/content.guardianapis.com\\\\/search\\\"}\"',	'2025-09-27 14:59:33',	'2025-09-27 14:59:33'),
(3,	'New York Times',	'nyt',	'nyt',	'\"{\\\"url\\\":\\\"https:\\\\/\\\\/api.nytimes.com\\\\/svc\\\\/search\\\\/v2\\\\/articlesearch.json\\\"}\"',	'2025-09-27 14:59:33',	'2025-09-27 14:59:33');
-- 2025-09-28 12:26:25 UTC
