SET NAMES utf8mb4;

INSERT INTO `user_preferences` (`id`, `user_id`, `preferred_sources`, `preferred_categories`, `preferred_authors`, `created_at`, `updated_at`) VALUES
(2,	2,	'[\"NewsAPI\"]',	'[\"Technology\"]',	'[\"Anonymous\"]',	'2025-09-27 20:42:40',	'2025-09-27 20:44:25'),
(4,	5,	'[\"NewsAPI\"]',	'[\"Sports\", \"Technology\"]',	'[\"Anonymous\"]',	'2025-09-28 12:27:12',	'2025-09-28 12:27:12');
-- 2025-09-28 12:27:51 UTC
